zk attendance
=============


zk.attendance
-------------

.. automodule:: zk.attendance
    :members:
    :undoc-members:
    :show-inheritance:

