.. toctree::
   :caption: IOT
   :name: topic5

###
IOT
###

It is possible to make a great IOT project by using pyzk. You can improve by using some hardware component like raspberry pi, relay, LED, or another stuff. Here we will show you an example of IOT impleentation. We will guide how to develops a Door Lock system implementation.

Door Lock Open
--------------

