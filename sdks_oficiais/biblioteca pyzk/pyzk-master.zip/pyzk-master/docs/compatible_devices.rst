.. toctree::
   :caption: Compatible Device
   :name: compatible_devices

##################
Compatible Devices
##################

